package com.example.Assingment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AssingmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
