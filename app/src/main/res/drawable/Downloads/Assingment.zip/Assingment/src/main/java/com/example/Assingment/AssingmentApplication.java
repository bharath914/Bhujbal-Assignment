package com.example.Assingment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AssingmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(AssingmentApplication.class, args);
	}

}
